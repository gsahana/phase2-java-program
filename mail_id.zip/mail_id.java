package program1;
import java.util.ArrayList;
import java.util.*;
public class mail_id {
public static void main(String[] args) {
        
        ArrayList<String> MailID = new ArrayList<String>();
        
        MailID.add("sharadha.rkin@gmx.com");
        MailID.add("rabitt.rksaha@gmx.com");
        MailID.add("teacoffee.hmmbb@gmx.com");
        MailID.add("minmax.ghfds@gmx.com");
        MailID.add("jhgfb.qwer@gmx.com");
        MailID.add("dfsad.hmgrh@gmx.com");
        MailID.add("sashine.njkyfg@gmx.com");
        
        String searchEmailID = "nisha.ytr@gmx.com";
        
        if(MailID.contains(searchEmailID)){
        	System.out.println(searchEmailID);
            System.out.println("EmailID found");
            
        }
        else{
        	System.out.println(searchEmailID);
            System.out.println( "EmailID not found");
        }
}
}
